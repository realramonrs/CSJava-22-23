package buclesAnidados;

public class ForAnidado {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Mostrar por pantalla n filas de n asteriscos
		int n = 3;
		
	for(int i = 0;i<10;i++) {	
		for(int j = 0;j<n;j++) {
			System.out.print("* ");
		} //Llave que cierra bucle j
		System.out.println();
		
	} //Llave que cierra bucle i
	}

}
