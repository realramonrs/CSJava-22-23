package bucles;

public class EjemploStrings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Ejemplos con Strings.
		//Buscar todas las posiciones en las que aparece un caracter en un String
		String palabra = "Elefante";
		String caracter = "e";
		
		System.out.println(caracter + " est� en las posiciones: ");
		for(int i = 0;i<palabra.length();i++) {
			
			if(palabra.substring(i,i+1).equalsIgnoreCase(caracter)  ) {
				System.out.print(i + " ");
			}
		}
		
	}

}
