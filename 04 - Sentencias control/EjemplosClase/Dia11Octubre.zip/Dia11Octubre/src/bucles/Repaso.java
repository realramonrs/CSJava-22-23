package bucles;

public class Repaso {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//3 tipos for, while do while
		// variable de control ---> i , j , k
		//inicializar la variable, condici�n de continuidad, modificarla
		int i = 7;
		
		while(i<100) {
			if(i % 7 == 0) {
				System.out.print(i + " ");
				
			}
			i++;
			
		} // Findel bucle while
	}

}
